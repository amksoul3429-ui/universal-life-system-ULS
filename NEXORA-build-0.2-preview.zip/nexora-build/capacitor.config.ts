import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.nexora.personal', appName: 'NEXORA', webDir: 'dist', bundledWebRuntime: false };
export default config;
