# NEXORA — The Personal Evolution System

A local-first React + TypeScript application adapted from the uploaded Universal Life System project.

## Included in this build milestone

- NEXORA rebrand and responsive dark interface
- Existing ULS modules retained: dashboard, missions, planner, goals, evolution, knowledge records, rewards, journal, reports and settings
- Local browser persistence for personal records
- Mission completion XP/credit engine and reward redemption logic
- JSON backup and restore
- New AI Assistant workspace with six selectable roles
- Optional OpenAI-compatible `/chat/completions` connection
- PWA manifest, app icon and service worker shell cache
- Capacitor configuration for the Android packaging stage

## Important status

This is the first implementation milestone, not the complete NEXORA specification. It does not yet include the production backend, secure server-side AI proxy, cloud sync, account authentication, encrypted storage, full curriculum/assessment engine, hybrid memory review workflow, proactive scheduler, voice services, or a generated Android Studio project/APK. The AI key is stored in browser local storage and sent directly to the configured provider; this is suitable only for a private development build, not a public deployment.

The PWA can be installed from a compatible browser after deployment over HTTPS. Android packaging requires the Capacitor Android platform and Android SDK.

## Run locally

```bash
npm install
npm run dev
```

## Production web build

```bash
npm run build
npm run preview
```

## Android packaging (requires Android Studio / SDK)

```bash
npm install @capacitor/android
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

Build an APK from Android Studio after configuring the Android SDK. This project intentionally does not include generated platform binaries.

## AI provider setup

Open NEXORA → Settings → AI Provider Connection. Configure an OpenAI-compatible base URL, model and API key. Provider compatibility, CORS policy, usage limits and charges depend on the provider. Do not use a personal production key in a shared/public deployment.
